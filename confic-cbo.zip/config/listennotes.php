<?php

return [
    'client_id' => env('LISTENNOTES_CLIENT_ID')
];
